import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowRight,
  Brain,
  Camera,
  CheckCircle2,
  Copy,
  Gauge,
  MapPin,
  Route as RouteIcon,
  ShieldCheck,
  Sparkles,
  Timer,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { SiteFooter, SiteHeader } from "@/components/civic/site-chrome";
import { fetchComplaints } from "@/lib/api";
import heroImage from "@/assets/hero-street.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CivicLens AI — See the Problem. Route the Action. Track the Impact." },
      {
        name: "description",
        content:
          "Report potholes, garbage, water leaks and broken streetlights. CivicLens AI classifies, prioritises and routes every civic complaint, then tracks accountability to resolution.",
      },
      { property: "og:title", content: "CivicLens AI — Civic Issue Reporting & Accountability" },
      {
        property: "og:description",
        content:
          "AI-powered civic issue reporting that turns citizen complaints into prioritised, actionable and accountable civic tasks.",
      },
    ],
  }),
  component: Landing,
});

const WORKFLOW = [
  { label: "Citizen Report", icon: Camera },
  { label: "AI Analysis", icon: Brain },
  { label: "Priority", icon: Gauge },
  { label: "Department", icon: RouteIcon },
  { label: "Action", icon: Timer },
  { label: "Resolution", icon: CheckCircle2 },
];

function Landing() {
  const { data: complaints = [] } = useQuery({
    queryKey: ["complaints", "public"],
    queryFn: fetchComplaints,
  });

  const total = complaints.length;
  const resolved = complaints.filter((c) => c.status === "resolved").length;
  const inProgress = complaints.filter((c) =>
    ["assigned", "in_progress"].includes(c.status),
  ).length;
  const highPriority = complaints.filter((c) =>
    ["high", "critical"].includes(c.priority),
  ).length;

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="flex-1">
        {/* HERO */}
        <section className="relative overflow-hidden bg-ink text-ink-foreground">
          <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:py-24">
            <div>
              <span className="eyebrow inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-primary">
                <Sparkles className="size-3.5" /> Civic Technology · Public Impact
              </span>
              <h1 className="mt-6 text-4xl leading-[1.05] font-bold sm:text-5xl lg:text-6xl">
                CivicLens <span className="text-primary">AI</span>
              </h1>
              <p className="mt-4 font-display text-xl font-semibold text-primary sm:text-2xl">
                See the Problem. Route the Action. Track the Impact.
              </p>
              <p className="mt-5 max-w-xl text-base leading-relaxed opacity-80">
                AI-powered civic issue reporting that turns citizen complaints into prioritised,
                actionable and accountable civic tasks.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button size="lg" asChild>
                  <Link to="/report">
                    Report an Issue <ArrowRight className="size-4" />
                  </Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-ink-foreground/25 bg-transparent text-ink-foreground hover:bg-ink-foreground/10 hover:text-ink-foreground"
                  asChild
                >
                  <Link to="/authority">Authority Dashboard</Link>
                </Button>
              </div>
            </div>

            <div className="relative">
              <img
                src={heroImage}
                alt="Municipal worker documenting a pothole on a city street with a smartphone"
                width={1280}
                height={960}
                className="w-full rounded-2xl border border-ink-foreground/15 object-cover shadow-2xl"
              />
              <div className="absolute -bottom-5 left-4 right-4 rounded-xl border border-border bg-card p-4 text-card-foreground shadow-lg sm:left-8 sm:right-8">
                <p className="eyebrow text-primary">AI classification</p>
                <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                  <span className="text-muted-foreground">Category</span>
                  <span className="font-semibold">Roads &amp; Potholes</span>
                  <span className="text-muted-foreground">Priority</span>
                  <span className="font-semibold text-destructive">High</span>
                  <span className="text-muted-foreground">Routed to</span>
                  <span className="font-semibold">Roads &amp; Infrastructure</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* WORKFLOW */}
        <section className="border-b border-border bg-card py-16 pt-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <p className="eyebrow text-primary">The pipeline</p>
            <h2 className="mt-2 text-2xl font-bold sm:text-3xl">
              One complaint, six accountable steps
            </h2>
            <ol className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
              {WORKFLOW.map((step, i) => (
                <li key={step.label} className="surface flex items-center gap-3 p-4">
                  <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-ink text-primary">
                    <step.icon className="size-4" />
                  </span>
                  <div>
                    <p className="text-[0.65rem] font-bold tracking-widest text-muted-foreground">
                      STEP {i + 1}
                    </p>
                    <p className="text-sm font-semibold">{step.label}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section id="how" className="py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <p className="eyebrow text-primary">How it works</p>
            <h2 className="mt-2 max-w-2xl text-2xl font-bold sm:text-3xl">
              Built so a complaint can never quietly disappear
            </h2>
            <div className="mt-8 grid gap-5 md:grid-cols-3">
              {[
                {
                  icon: Camera,
                  title: "Report in under a minute",
                  body: "Describe the issue, attach a photo and capture your location from the browser — or type it manually if GPS is unavailable.",
                },
                {
                  icon: Brain,
                  title: "AI reads text and photo",
                  body: "The complaint is classified into a category and subcategory, scored for severity and priority, and matched to the responsible department.",
                },
                {
                  icon: ShieldCheck,
                  title: "Authority stays accountable",
                  body: "Every verification, assignment, status change and public update is timestamped and visible to the citizen who reported it.",
                },
              ].map((c) => (
                <article key={c.title} className="surface p-6">
                  <span className="grid size-10 place-items-center rounded-xl bg-primary/12 text-primary">
                    <c.icon className="size-5" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold">{c.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{c.body}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* AI INTELLIGENCE */}
        <section className="bg-ink py-16 text-ink-foreground">
          <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-2">
            <div>
              <p className="eyebrow text-primary">AI intelligence</p>
              <h2 className="mt-2 text-2xl font-bold sm:text-3xl">
                AI is core here — not decorative
              </h2>
              <p className="mt-4 max-w-lg opacity-75">
                Each report is analysed on submission. Nothing is pre-written: the category,
                severity, priority, department and reasoning come from the actual complaint text and
                the uploaded photo.
              </p>
              <ul className="mt-6 space-y-3 text-sm">
                {[
                  "Classifies the issue into category and subcategory",
                  "Scores severity from public-safety risk",
                  "Calculates priority from severity, location and impact",
                  "Detects semantically similar existing reports",
                  "Recommends routing with a written explanation",
                ].map((item) => (
                  <li key={item} className="flex gap-3">
                    <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-primary" />
                    <span className="opacity-85">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {[
                { icon: Copy, title: "Duplicate detection", body: "Text similarity + category + geographic proximity. Matches are surfaced, never auto-merged." },
                { icon: RouteIcon, title: "Auto routing", body: "Potholes to Roads, garbage to Sanitation, leaks to Water Supply — with authority override." },
                { icon: Gauge, title: "Priority scoring", body: "Safety-critical issues at schools and junctions rise above cosmetic complaints." },
                { icon: MapPin, title: "Location intelligence", body: "Browser geolocation with a manual fallback, plotted on the authority map view." },
              ].map((c) => (
                <div key={c.title} className="rounded-xl border border-ink-foreground/15 bg-ink-foreground/5 p-5">
                  <c.icon className="size-5 text-primary" />
                  <h3 className="mt-3 font-display text-base font-semibold">{c.title}</h3>
                  <p className="mt-1.5 text-sm opacity-70">{c.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ACCOUNTABILITY */}
        <section className="py-16">
          <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
            <div>
              <p className="eyebrow text-primary">Accountability</p>
              <h2 className="mt-2 text-2xl font-bold sm:text-3xl">A timeline, not a black box</h2>
              <p className="mt-4 text-muted-foreground">
                Citizens see exactly who acted, when, and what they said. Authorities can add public
                updates for the reporter and internal notes for their own team.
              </p>
            </div>
            <ol className="surface divide-y divide-border overflow-hidden p-0">
              {[
                ["Submitted", "Citizen files the report with photo and location"],
                ["Verified", "Authority confirms the issue is genuine"],
                ["Assigned", "Routed to the responsible department"],
                ["In Progress", "Field crew dispatched"],
                ["Resolved", "Closure recorded with a public note"],
              ].map(([label, body], i) => (
                <li key={label} className="flex items-start gap-4 p-4">
                  <span className="grid size-7 shrink-0 place-items-center rounded-full bg-primary/12 text-xs font-bold text-primary">
                    {i + 1}
                  </span>
                  <div>
                    <p className="text-sm font-semibold">{label}</p>
                    <p className="text-sm text-muted-foreground">{body}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* IMPACT */}
        <section className="border-t border-border bg-card py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <p className="eyebrow text-primary">Impact dashboard</p>
            <h2 className="mt-2 text-2xl font-bold sm:text-3xl">Live numbers from this platform</h2>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                ["Total reports", total],
                ["High &amp; critical priority", highPriority],
                ["Currently being actioned", inProgress],
                ["Resolved", resolved],
              ].map(([label, value]) => (
                <div key={String(label)} className="surface p-6">
                  <p className="font-display text-4xl font-bold text-primary">{value as number}</p>
                  <p
                    className="mt-1 text-sm text-muted-foreground"
                    dangerouslySetInnerHTML={{ __html: String(label) }}
                  />
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild>
                <Link to="/report">Report an Issue</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link to="/how-it-works">See how it works</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
