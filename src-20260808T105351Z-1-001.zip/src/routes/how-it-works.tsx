import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteFooter, SiteHeader } from "@/components/civic/site-chrome";
import { ROUTING } from "@/lib/civic";

export const Route = createFileRoute("/how-it-works")({
  head: () => ({
    meta: [
      { title: "How CivicLens AI Works — From Report to Resolution" },
      {
        name: "description",
        content:
          "Understand how CivicLens AI analyses a civic complaint, scores priority, detects duplicates, routes it to the right department and tracks accountability.",
      },
      { property: "og:title", content: "How CivicLens AI Works" },
      {
        property: "og:description",
        content: "From citizen report to AI analysis, routing, authority action and resolution.",
      },
    ],
  }),
  component: HowItWorks,
});

const STEPS = [
  {
    title: "1 · Citizen files a report",
    body: "Describe the problem in plain language, attach a photo as evidence and capture your location from the browser. If GPS is blocked, type the location manually — the report is never blocked.",
  },
  {
    title: "2 · AI analyses text and image",
    body: "The description and photo are sent to a secure backend function. No API key ever reaches the browser. The model returns category, subcategory, severity, priority, confidence, a summary and its reasoning.",
  },
  {
    title: "3 · Duplicate detection",
    body: "The new report is compared with existing complaints using word-level text similarity, category match and geographic distance. Possible duplicates are shown to the citizen with a similarity score and distance — nothing is merged automatically.",
  },
  {
    title: "4 · Automatic routing",
    body: "Each category maps to a responsible department. The AI recommendation is applied on submission and an authority can override it at any time.",
  },
  {
    title: "5 · Authority action",
    body: "Authorities verify, assign, re-prioritise, post public updates, keep internal notes and move the complaint through its lifecycle. Every change is written to an immutable status history.",
  },
  {
    title: "6 · Citizen tracking",
    body: "The reporter sees the full accountability timeline: who acted, when, and what they said, until the issue is resolved or formally rejected.",
  },
];

function HowItWorks() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="bg-ink py-14 text-ink-foreground">
          <div className="mx-auto max-w-4xl px-4 sm:px-6">
            <p className="eyebrow text-primary">How it works</p>
            <h1 className="mt-2 text-3xl font-bold sm:text-4xl">
              From a photo on the street to an accountable civic task
            </h1>
            <p className="mt-4 max-w-2xl opacity-75">
              CivicLens AI does not just collect complaints. It reads them, ranks them, routes them
              and keeps the record open.
            </p>
          </div>
        </section>

        <section className="py-14">
          <div className="mx-auto grid max-w-4xl gap-4 px-4 sm:px-6">
            {STEPS.map((s) => (
              <article key={s.title} className="surface p-6">
                <h2 className="font-display text-lg font-semibold">{s.title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="border-t border-border bg-card py-14">
          <div className="mx-auto max-w-4xl px-4 sm:px-6">
            <p className="eyebrow text-primary">Routing table</p>
            <h2 className="mt-2 text-2xl font-bold">Which department gets what</h2>
            <div className="mt-6 overflow-hidden rounded-xl border border-border">
              <table className="w-full text-sm">
                <thead className="bg-muted/60 text-left">
                  <tr>
                    <th className="px-4 py-3 font-semibold">Issue category</th>
                    <th className="px-4 py-3 font-semibold">Responsible department</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border bg-card">
                  {Object.entries(ROUTING).map(([category, slug]) => (
                    <tr key={category}>
                      <td className="px-4 py-3">{category}</td>
                      <td className="px-4 py-3 font-medium capitalize">{slug.replace("-", " ")}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild>
                <Link to="/report">Report an Issue</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link to="/register">Create an account</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
