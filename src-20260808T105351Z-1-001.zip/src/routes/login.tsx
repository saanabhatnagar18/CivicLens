import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { ScanEye } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Log in — CivicLens AI" },
      {
        name: "description",
        content: "Sign in to report civic issues or manage complaints on CivicLens AI.",
      },
      { property: "og:title", content: "Log in to CivicLens AI" },
      { property: "og:description", content: "Access your civic reports and authority tools." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { data, error: signInError } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    setLoading(false);
    if (signInError) {
      setError(signInError.message);
      toast.error("Could not sign in", { description: signInError.message });
      return;
    }
    toast.success("Welcome back");
    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", data.user.id);
    const isAuthority = (roles ?? []).some((r) => r.role === "authority" || r.role === "admin");
    void navigate({ to: isAuthority ? "/authority" : "/dashboard" });
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="hidden flex-col justify-between bg-ink p-10 text-ink-foreground lg:flex">
        <Link to="/" className="flex items-center gap-2.5">
          <span className="grid size-9 place-items-center rounded-xl bg-ink-foreground/10">
            <ScanEye className="size-5 text-primary" />
          </span>
          <span className="font-display text-lg font-bold">
            CivicLens<span className="text-primary"> AI</span>
          </span>
        </Link>
        <div>
          <h2 className="font-display text-3xl font-bold">
            See the Problem. Route the Action. Track the Impact.
          </h2>
          <p className="mt-4 max-w-md opacity-70">
            Sign in to file a civic report or to manage the complaints assigned to your department.
          </p>
        </div>
        <p className="text-xs opacity-50">Civic Technology · Public Impact</p>
      </div>

      <div className="flex items-center justify-center px-4 py-14">
        <div className="w-full max-w-sm">
          <Link to="/" className="mb-8 flex items-center gap-2 lg:hidden">
            <ScanEye className="size-5 text-primary" />
            <span className="font-display font-bold">CivicLens AI</span>
          </Link>
          <h1 className="font-display text-2xl font-bold">Log in</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Use the email and password you registered with.
          </p>

          <form onSubmit={onSubmit} className="mt-6 space-y-4" noValidate>
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
            </div>

            {error ? (
              <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {error}
              </p>
            ) : null}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Signing in…" : "Log in"}
            </Button>
          </form>

          <p className="mt-6 text-sm text-muted-foreground">
            New here?{" "}
            <Link to="/register" className="font-semibold text-primary hover:underline">
              Create an account
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
