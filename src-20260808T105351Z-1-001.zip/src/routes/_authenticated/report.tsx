import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useRef, useState } from "react";
import { toast } from "sonner";
import {
  Camera,
  CheckCircle2,
  Copy,
  Crosshair,
  Loader2,
  Sparkles,
  Upload,
  X,
} from "lucide-react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { analyseComplaint, type AiAnalysis } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { PriorityBadge, StatusBadge } from "@/components/civic/badges";
import { useAuth } from "@/hooks/useAuth";
import {
  findDuplicates,
  formatDate,
  type DuplicateCandidate,
  type DuplicateResult,
} from "@/lib/civic";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/report")({
  head: () => ({
    meta: [
      { title: "Report a Civic Issue — CivicLens AI" },
      {
        name: "description",
        content:
          "Describe the problem, attach a photo and capture your location. CivicLens AI classifies, prioritises and routes your report automatically.",
      },
      { property: "og:title", content: "Report a Civic Issue" },
      { property: "og:description", content: "AI-assisted civic complaint reporting." },
    ],
  }),
  component: ReportPage,
});

const AI_STEPS = [
  "Analysing description",
  "Analysing image",
  "Classifying issue",
  "Assessing severity",
  "Calculating priority",
  "Finding responsible department",
  "Checking duplicate reports",
];

const formSchema = z.object({
  description: z
    .string()
    .trim()
    .min(15, "Please describe the issue in at least 15 characters")
    .max(2000, "Description must be under 2000 characters"),
  locationText: z.string().trim().min(3, "Add a location").max(300),
});

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

type Phase = "form" | "processing" | "review";

function ReportPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user, fullName } = useAuth();
  const runAi = useServerFn(analyseComplaint);
  const fileRef = useRef<HTMLInputElement>(null);

  const [description, setDescription] = useState("");
  const [locationText, setLocationText] = useState("");
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [geoLoading, setGeoLoading] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [phase, setPhase] = useState<Phase>("form");
  const [stepIndex, setStepIndex] = useState(0);
  const [analysis, setAnalysis] = useState<AiAnalysis | null>(null);
  const [duplicates, setDuplicates] = useState<DuplicateResult[]>([]);
  const [saving, setSaving] = useState(false);

  const captureLocation = () => {
    if (!("geolocation" in navigator)) {
      toast.error("Geolocation is not supported — enter the location manually");
      return;
    }
    setGeoLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGeoLoading(false);
        const lat = Number(pos.coords.latitude.toFixed(6));
        const lng = Number(pos.coords.longitude.toFixed(6));
        setCoords({ lat, lng });
        if (!locationText.trim()) setLocationText(`Lat ${lat}, Lng ${lng}`);
        toast.success("Location captured");
      },
      () => {
        setGeoLoading(false);
        toast.error("Could not get your location", {
          description: "Please type the location manually instead.",
        });
      },
      { enableHighAccuracy: true, timeout: 10000 },
    );
  };

  const onPickImage = (file: File | null) => {
    if (!file) return;
    if (!/^image\/(png|jpeg|jpg|webp)$/.test(file.type)) {
      toast.error("Only PNG, JPG or WebP images are allowed");
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      toast.error("Image must be smaller than 5 MB");
      return;
    }
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = () => setImagePreview(String(reader.result));
    reader.readAsDataURL(file);
  };

  const analysisMutation = useMutation({
    mutationFn: async () => {
      const parsed = formSchema.safeParse({ description, locationText });
      if (!parsed.success) throw new Error(parsed.error.issues[0]?.message ?? "Invalid input");

      setPhase("processing");
      setStepIndex(0);
      const timer = setInterval(() => {
        setStepIndex((i) => Math.min(i + 1, AI_STEPS.length - 2));
      }, 700);

      try {
        const result = await runAi({
          data: {
            description: parsed.data.description,
            locationText: parsed.data.locationText,
            imageDataUrl: imagePreview,
          },
        });

        setStepIndex(AI_STEPS.length - 1);

        const { data: existing } = await supabase
          .from("complaints")
          .select("id, code, description, category, status, latitude, longitude, created_at")
          .neq("status", "rejected")
          .order("created_at", { ascending: false })
          .limit(200);

        const dupes = findDuplicates(
          parsed.data.description,
          result.category,
          coords?.lat ?? null,
          coords?.lng ?? null,
          (existing ?? []) as DuplicateCandidate[],
        );
        return { result, dupes };
      } finally {
        clearInterval(timer);
      }
    },
    onSuccess: ({ result, dupes }) => {
      setAnalysis(result);
      setDuplicates(dupes);
      setPhase("review");
    },
    onError: (err: Error) => {
      setPhase("form");
      const message =
        err.message === "RATE_LIMIT"
          ? "AI is rate limited right now. Please retry in a moment."
          : err.message === "NO_CREDITS"
            ? "AI credits are exhausted for this workspace."
            : err.message;
      setError(message);
      toast.error("Analysis failed", { description: message });
    },
  });

  const submitReport = async (linkTo: DuplicateResult | null) => {
    if (!analysis || !user) return;
    setSaving(true);
    try {
      let imageUrl: string | null = null;
      if (imageFile) {
        const ext = imageFile.name.split(".").pop() || "jpg";
        const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
        const { error: uploadError } = await supabase.storage
          .from("complaint-images")
          .upload(path, imageFile, { contentType: imageFile.type });
        if (uploadError) throw new Error(uploadError.message);
        const { data: signed } = await supabase.storage
          .from("complaint-images")
          .createSignedUrl(path, 60 * 60 * 24 * 365);
        imageUrl = signed?.signedUrl ?? null;
      }

      const { data: dept } = await supabase
        .from("departments")
        .select("id")
        .eq("slug", analysis.departmentSlug)
        .maybeSingle();

      const title = description.trim().split(/[.\n]/)[0]?.slice(0, 90) || analysis.subcategory;

      const { data: created, error: insertError } = await supabase
        .from("complaints")
        .insert({
          citizen_id: user.id,
          reporter_name: fullName || user.email || "Citizen",
          title,
          description: description.trim(),
          category: analysis.category,
          subcategory: analysis.subcategory,
          severity: analysis.severity,
          priority: analysis.priority,
          department_id: dept?.id ?? null,
          location_text: locationText.trim(),
          latitude: coords?.lat ?? null,
          longitude: coords?.lng ?? null,
          image_url: imageUrl,
          ai_confidence: analysis.confidence,
          ai_summary: analysis.summary,
          is_duplicate_of: linkTo ? linkTo.candidate.id : null,
        })
        .select("id, code")
        .single();
      if (insertError) throw new Error(insertError.message);

      await Promise.all([
        supabase.from("ai_analysis").insert({
          complaint_id: created.id,
          category: analysis.category,
          subcategory: analysis.subcategory,
          severity: analysis.severity,
          priority: analysis.priority,
          department_slug: analysis.departmentSlug,
          confidence: analysis.confidence,
          summary: analysis.summary,
          reasoning: analysis.reasoning,
          image_findings: analysis.imageFindings,
          model: analysis.model,
          demo_mode: analysis.demoMode,
        }),
        supabase.from("complaint_status_history").insert({
          complaint_id: created.id,
          from_status: null,
          to_status: "submitted",
          changed_by: user.id,
          changed_by_name: fullName || user.email || "Citizen",
          note: `Auto-routed to the ${analysis.departmentSlug} department by CivicLens AI.`,
        }),
        imageUrl
          ? supabase.from("complaint_images").insert({ complaint_id: created.id, url: imageUrl })
          : Promise.resolve(),
        duplicates.length
          ? supabase.from("duplicate_matches").insert(
              duplicates.map((d) => ({
                complaint_id: created.id,
                matched_complaint_id: d.candidate.id,
                similarity: Number(d.similarity.toFixed(2)),
                distance_m: d.distance,
                reason: d.reason,
                linked: linkTo?.candidate.id === d.candidate.id,
              })),
            )
          : Promise.resolve(),
      ]);

      await queryClient.invalidateQueries();
      toast.success(`Report ${created.code} submitted`, {
        description: linkTo
          ? `Linked to existing report ${linkTo.candidate.code}.`
          : "Routed to the responsible department.",
      });
      void navigate({ to: "/complaints/$id", params: { id: created.id } });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not submit the report";
      toast.error("Submission failed", { description: message });
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
      <p className="eyebrow text-primary">Citizen report</p>
      <h1 className="mt-2 text-2xl font-bold sm:text-3xl">Report a civic issue</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        Describe what you see. CivicLens AI will classify the issue, score its priority, check for
        duplicates and route it to the responsible department.
      </p>

      {phase === "form" ? (
        <form
          className="surface mt-6 space-y-6 p-6"
          onSubmit={(e) => {
            e.preventDefault();
            setError(null);
            analysisMutation.mutate();
          }}
          noValidate
        >
          <div className="space-y-1.5">
            <Label htmlFor="description">Issue description</Label>
            <Textarea
              id="description"
              rows={5}
              maxLength={2000}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="There is a large pothole near the college entrance. Bikes are struggling to pass and it could cause an accident."
            />
            <p className="text-xs text-muted-foreground">{description.length}/2000 characters</p>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="photo">Photo evidence (optional)</Label>
            {imagePreview ? (
              <div className="relative w-fit">
                <img
                  src={imagePreview}
                  alt="Preview of the civic issue you are reporting"
                  className="max-h-56 rounded-xl border border-border object-cover"
                />
                <button
                  type="button"
                  aria-label="Remove image"
                  onClick={() => {
                    setImageFile(null);
                    setImagePreview(null);
                    if (fileRef.current) fileRef.current.value = "";
                  }}
                  className="absolute -top-2 -right-2 grid size-7 place-items-center rounded-full bg-ink text-ink-foreground"
                >
                  <X className="size-4" />
                </button>
              </div>
            ) : (
              <label
                htmlFor="photo"
                className="flex cursor-pointer flex-col items-center gap-2 rounded-xl border border-dashed border-input bg-muted/40 px-4 py-8 text-center text-sm text-muted-foreground hover:bg-muted"
              >
                <Upload className="size-5" />
                <span>Click to upload a photo (PNG, JPG or WebP · max 5 MB)</span>
              </label>
            )}
            <input
              ref={fileRef}
              id="photo"
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="sr-only"
              onChange={(e) => onPickImage(e.target.files?.[0] ?? null)}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="location">Location</Label>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Input
                id="location"
                required
                maxLength={300}
                value={locationText}
                onChange={(e) => setLocationText(e.target.value)}
                placeholder="MG Road, near City College entrance"
              />
              <Button
                type="button"
                variant="outline"
                onClick={captureLocation}
                disabled={geoLoading}
                className="shrink-0"
              >
                {geoLoading ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Crosshair className="size-4" />
                )}
                Use current location
              </Button>
            </div>
            {coords ? (
              <p className="text-xs text-success">
                GPS captured: {coords.lat}, {coords.lng}
              </p>
            ) : (
              <p className="text-xs text-muted-foreground">
                GPS is optional — a typed location still works, but coordinates improve duplicate
                detection.
              </p>
            )}
          </div>

          {error ? (
            <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </p>
          ) : null}

          <Button type="submit" size="lg" className="w-full sm:w-auto">
            <Sparkles className="size-4" />
            Analyse &amp; Submit Report
          </Button>
        </form>
      ) : null}

      {phase === "processing" ? (
        <div className="surface mt-6 p-8">
          <div className="flex items-center gap-3">
            <Loader2 className="size-5 animate-spin text-primary" />
            <p className="font-display text-lg font-semibold">CivicLens AI is analysing…</p>
          </div>
          <ol className="mt-6 space-y-3">
            {AI_STEPS.map((step, i) => {
              const done = i < stepIndex;
              const active = i === stepIndex;
              return (
                <li
                  key={step}
                  className={cn(
                    "flex items-center gap-3 text-sm",
                    done ? "text-foreground" : active ? "text-foreground" : "text-muted-foreground",
                  )}
                >
                  {done ? (
                    <CheckCircle2 className="size-4 text-success" />
                  ) : active ? (
                    <Loader2 className="size-4 animate-spin text-primary" />
                  ) : (
                    <span className="size-4 rounded-full border border-border" />
                  )}
                  {step}
                </li>
              );
            })}
          </ol>
        </div>
      ) : null}

      {phase === "review" && analysis ? (
        <div className="mt-6 space-y-5">
          <section className="surface p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Sparkles className="size-4 text-primary" />
                <h2 className="font-display text-lg font-semibold">AI analysis result</h2>
              </div>
              {analysis.demoMode ? (
                <span className="rounded-full border border-warning/40 bg-warning/20 px-3 py-1 text-xs font-semibold">
                  DEMO AI MODE
                </span>
              ) : (
                <span className="text-xs text-muted-foreground">Model: {analysis.model}</span>
              )}
            </div>

            <dl className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[
                ["Category", analysis.category],
                ["Subcategory", analysis.subcategory],
                ["Department", analysis.departmentSlug],
              ].map(([k, v]) => (
                <div key={k}>
                  <dt className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                    {k}
                  </dt>
                  <dd className="mt-1 text-sm font-semibold capitalize">{v}</dd>
                </div>
              ))}
              <div>
                <dt className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                  Severity
                </dt>
                <dd className="mt-1">
                  <PriorityBadge level={analysis.severity} />
                </dd>
              </div>
              <div>
                <dt className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                  Priority
                </dt>
                <dd className="mt-1">
                  <PriorityBadge level={analysis.priority} />
                </dd>
              </div>
              <div>
                <dt className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                  Confidence
                </dt>
                <dd className="mt-1 text-sm font-semibold">
                  {Math.round(analysis.confidence * 100)}%
                </dd>
              </div>
            </dl>

            <div className="mt-5 space-y-3 border-t border-border pt-4 text-sm">
              <p>
                <span className="font-semibold">Summary: </span>
                {analysis.summary}
              </p>
              <p className="text-muted-foreground">
                <span className="font-semibold text-foreground">Reasoning: </span>
                {analysis.reasoning}
              </p>
              {analysis.imageFindings ? (
                <p className="text-muted-foreground">
                  <span className="font-semibold text-foreground">Image findings: </span>
                  {analysis.imageFindings}
                </p>
              ) : null}
            </div>
          </section>

          {duplicates.length ? (
            <section className="rounded-xl border-2 border-warning/50 bg-warning/10 p-6">
              <div className="flex items-center gap-2">
                <Copy className="size-4" />
                <h2 className="font-display text-lg font-semibold">Possible Duplicate Detected</h2>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">
                We found existing reports that look similar. Nothing is merged automatically — you
                decide.
              </p>
              <ul className="mt-4 space-y-3">
                {duplicates.map((d) => (
                  <li key={d.candidate.id} className="rounded-xl border border-border bg-card p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-display text-sm font-bold">{d.candidate.code}</span>
                      <StatusBadge status={d.candidate.status} />
                    </div>
                    <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
                      {d.candidate.description}
                    </p>
                    <div className="mt-3 flex flex-wrap gap-4 text-xs text-muted-foreground">
                      <span>
                        Similarity:{" "}
                        <strong className="text-foreground">
                          {Math.round(d.similarity * 100)}%
                        </strong>
                      </span>
                      <span>
                        Distance:{" "}
                        <strong className="text-foreground">
                          {d.distance == null ? "unknown" : `${d.distance} m`}
                        </strong>
                      </span>
                      <span>Reported {formatDate(d.candidate.created_at)}</span>
                    </div>
                    <Button
                      className="mt-3"
                      size="sm"
                      variant="outline"
                      disabled={saving}
                      onClick={() => void submitReport(d)}
                    >
                      Link to Existing Issue
                    </Button>
                  </li>
                ))}
              </ul>
            </section>
          ) : (
            <p className="rounded-xl border border-success/30 bg-success/10 px-4 py-3 text-sm text-success">
              No similar existing report was found nearby.
            </p>
          )}

          <div className="flex flex-wrap gap-3">
            <Button size="lg" disabled={saving} onClick={() => void submitReport(null)}>
              {saving ? <Loader2 className="size-4 animate-spin" /> : <Camera className="size-4" />}
              Continue as New Report
            </Button>
            <Button
              size="lg"
              variant="ghost"
              disabled={saving}
              onClick={() => {
                setPhase("form");
                setAnalysis(null);
                setDuplicates([]);
              }}
            >
              Edit report
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
