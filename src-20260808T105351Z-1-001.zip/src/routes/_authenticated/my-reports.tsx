import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { fetchMyComplaints } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { STATUS_LABEL, type ComplaintStatus } from "@/lib/civic";
import {
  ComplaintCard,
  EmptyState,
  ErrorBlock,
  LoadingBlock,
} from "@/components/civic/complaint-ui";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/my-reports")({
  head: () => ({
    meta: [
      { title: "My Reports — CivicLens AI" },
      {
        name: "description",
        content: "Every civic complaint you have filed, searchable and filterable by status.",
      },
      { property: "og:title", content: "My Reports — CivicLens AI" },
      { property: "og:description", content: "Search and filter your civic complaints." },
    ],
  }),
  component: MyReports,
});

const FILTERS: Array<ComplaintStatus | "all"> = [
  "all",
  "submitted",
  "verified",
  "assigned",
  "in_progress",
  "resolved",
  "rejected",
];

function MyReports() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<ComplaintStatus | "all">("all");

  const { data, isLoading, error } = useQuery({
    queryKey: ["complaints", "mine", user?.id],
    queryFn: () => fetchMyComplaints(user!.id),
    enabled: Boolean(user?.id),
  });

  const complaints = (data ?? []).filter((c) => {
    const matchesStatus = status === "all" || c.status === status;
    const q = search.trim().toLowerCase();
    const matchesSearch =
      !q ||
      c.code.toLowerCase().includes(q) ||
      c.title.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q) ||
      c.category.toLowerCase().includes(q);
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <p className="eyebrow text-primary">My reports</p>
      <h1 className="mt-2 text-2xl font-bold sm:text-3xl">All complaints you have filed</h1>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by ID, category or text"
          className="sm:max-w-xs"
          aria-label="Search my reports"
        />
        <div className="flex flex-wrap gap-2">
          {FILTERS.map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setStatus(f)}
              className={cn(
                "rounded-full border px-3 py-1 text-xs font-semibold transition-colors",
                status === f
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card text-muted-foreground hover:bg-muted",
              )}
            >
              {f === "all" ? "All" : STATUS_LABEL[f]}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6">
        {isLoading ? (
          <LoadingBlock />
        ) : error ? (
          <ErrorBlock message={(error as Error).message} />
        ) : complaints.length === 0 ? (
          <EmptyState
            title="Nothing matches"
            body="No report matches your current search or filter."
            action={
              <Button className="mt-3" asChild>
                <Link to="/report">Report an issue</Link>
              </Button>
            }
          />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {complaints.map((c) => (
              <ComplaintCard key={c.id} complaint={c} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
