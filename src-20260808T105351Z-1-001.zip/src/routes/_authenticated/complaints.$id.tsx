import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Copy, Lock, MapPin, Megaphone, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PriorityBadge, StatusBadge } from "@/components/civic/badges";
import { ErrorBlock } from "@/components/civic/complaint-ui";
import { useAuth } from "@/hooks/useAuth";
import {
  addUpdate,
  changeStatus,
  fetchAnalysis,
  fetchComplaint,
  fetchDepartments,
  fetchDuplicates,
  fetchHistory,
  fetchUpdates,
  updateComplaintFields,
} from "@/lib/api";
import {
  STATUS_FLOW,
  STATUS_LABEL,
  formatDateTime,
  type ComplaintStatus,
  type Severity,
} from "@/lib/civic";

export const Route = createFileRoute("/_authenticated/complaints/$id")({
  head: () => ({
    meta: [
      { title: "Complaint Details — CivicLens AI" },
      {
        name: "description",
        content:
          "Full complaint record: photo evidence, AI analysis, routing, duplicate matches and the accountability timeline.",
      },
      { property: "og:title", content: "Complaint Details — CivicLens AI" },
      { property: "og:description", content: "AI analysis and accountability timeline." },
    ],
  }),
  component: ComplaintDetails,
});

const SEVERITIES: Severity[] = ["low", "medium", "high", "critical"];
const ALL_STATUSES: ComplaintStatus[] = [...STATUS_FLOW, "rejected"];

function ComplaintDetails() {
  const { id } = Route.useParams();
  const { user, fullName, isAuthority } = useAuth();
  const queryClient = useQueryClient();

  const complaintQuery = useQuery({ queryKey: ["complaint", id], queryFn: () => fetchComplaint(id) });
  const analysisQuery = useQuery({ queryKey: ["analysis", id], queryFn: () => fetchAnalysis(id) });
  const historyQuery = useQuery({ queryKey: ["history", id], queryFn: () => fetchHistory(id) });
  const updatesQuery = useQuery({ queryKey: ["updates", id], queryFn: () => fetchUpdates(id) });
  const dupesQuery = useQuery({ queryKey: ["dupes", id], queryFn: () => fetchDuplicates(id) });
  const deptQuery = useQuery({ queryKey: ["departments"], queryFn: fetchDepartments });

  const [note, setNote] = useState("");
  const [publicMessage, setPublicMessage] = useState("");
  const [internalNote, setInternalNote] = useState("");

  const complaint = complaintQuery.data;
  const departments = deptQuery.data ?? [];
  const department = departments.find((d) => d.id === complaint?.department_id);

  const refresh = async () => {
    await queryClient.invalidateQueries();
  };

  const statusMutation = useMutation({
    mutationFn: async (to: ComplaintStatus) => {
      if (!complaint || !user) throw new Error("Not ready");
      await changeStatus({
        complaintId: complaint.id,
        from: complaint.status,
        to,
        ...(note.trim() ? { note: note.trim() } : {}),
        actorId: user.id,
        actorName: fullName || user.email || "Authority",
      });
    },
    onSuccess: async (_d, to) => {
      setNote("");
      await refresh();
      toast.success(`Status changed to ${STATUS_LABEL[to]}`);
    },
    onError: (e: Error) => toast.error("Could not change status", { description: e.message }),
  });

  const fieldMutation = useMutation({
    mutationFn: async (patch: Record<string, unknown>) => {
      if (!complaint) throw new Error("Not ready");
      await updateComplaintFields(complaint.id, patch);
    },
    onSuccess: async () => {
      await refresh();
      toast.success("Complaint updated");
    },
    onError: (e: Error) => toast.error("Update failed", { description: e.message }),
  });

  const updateMutation = useMutation({
    mutationFn: async ({ message, isInternal }: { message: string; isInternal: boolean }) => {
      if (!complaint || !user) throw new Error("Not ready");
      if (message.trim().length < 3) throw new Error("Write a longer message");
      await addUpdate({
        complaintId: complaint.id,
        message: message.trim(),
        isInternal,
        authorId: user.id,
        authorName: fullName || user.email || "Authority",
      });
    },
    onSuccess: async (_d, vars) => {
      if (vars.isInternal) setInternalNote("");
      else setPublicMessage("");
      await refresh();
      toast.success(vars.isInternal ? "Internal note saved" : "Public update posted");
    },
    onError: (e: Error) => toast.error("Could not save", { description: e.message }),
  });

  if (complaintQuery.isLoading) {
    return <div className="mx-auto max-w-5xl px-4 py-10 text-sm text-muted-foreground">Loading complaint…</div>;
  }
  if (complaintQuery.error) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-10">
        <ErrorBlock message={(complaintQuery.error as Error).message} />
      </div>
    );
  }
  if (!complaint) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-16 text-center">
        <h1 className="font-display text-xl font-bold">Complaint not found</h1>
        <Link to="/dashboard" className="mt-3 inline-block text-sm font-semibold text-primary">
          Back to dashboard
        </Link>
      </div>
    );
  }

  const analysis = analysisQuery.data;
  const history = historyQuery.data ?? [];
  const updates = updatesQuery.data ?? [];
  const dupes = dupesQuery.data ?? [];

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <Link
        to={isAuthority ? "/authority/complaints" : "/my-reports"}
        className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" /> Back
      </Link>

      <div className="mt-4 flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="font-display text-sm font-bold text-primary">{complaint.code}</p>
          <h1 className="mt-1 text-2xl font-bold sm:text-3xl">
            {complaint.title || complaint.category}
          </h1>
          <p className="mt-2 inline-flex items-center gap-1.5 text-sm text-muted-foreground">
            <MapPin className="size-4" />
            {complaint.location_text || "Location not provided"}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <StatusBadge status={complaint.status} />
          <PriorityBadge level={complaint.priority} label="Priority" />
          <PriorityBadge level={complaint.severity} label="Severity" />
        </div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.35fr_0.65fr]">
        <div className="space-y-6">
          {complaint.image_url ? (
            <img
              src={complaint.image_url}
              alt={`Photo evidence submitted for complaint ${complaint.code}`}
              loading="lazy"
              className="max-h-96 w-full rounded-xl border border-border object-cover"
            />
          ) : null}

          <section className="surface p-6">
            <h2 className="font-display text-lg font-semibold">Complaint description</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              {complaint.description}
            </p>
            <dl className="mt-4 grid gap-3 border-t border-border pt-4 text-sm sm:grid-cols-3">
              <div>
                <dt className="text-xs text-muted-foreground uppercase">Reported by</dt>
                <dd className="font-medium">{complaint.reporter_name || "Citizen"}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground uppercase">Reported on</dt>
                <dd className="font-medium">{formatDateTime(complaint.created_at)}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground uppercase">Department</dt>
                <dd className="font-medium">{department?.name ?? "Unassigned"}</dd>
              </div>
            </dl>
          </section>

          <section className="surface p-6">
            <div className="flex items-center gap-2">
              <Sparkles className="size-4 text-primary" />
              <h2 className="font-display text-lg font-semibold">AI analysis</h2>
              {analysis?.demo_mode ? (
                <span className="rounded-full border border-warning/40 bg-warning/20 px-2 py-0.5 text-[0.65rem] font-bold">
                  DEMO AI MODE
                </span>
              ) : null}
            </div>
            {analysis ? (
              <>
                <dl className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <div>
                    <dt className="text-xs text-muted-foreground uppercase">Category</dt>
                    <dd className="text-sm font-semibold">{analysis.category}</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-muted-foreground uppercase">Subcategory</dt>
                    <dd className="text-sm font-semibold">{analysis.subcategory ?? "—"}</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-muted-foreground uppercase">Confidence</dt>
                    <dd className="text-sm font-semibold">
                      {analysis.confidence != null
                        ? `${Math.round(Number(analysis.confidence) * 100)}%`
                        : "—"}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-muted-foreground uppercase">Routed to</dt>
                    <dd className="text-sm font-semibold capitalize">
                      {analysis.department_slug ?? "—"}
                    </dd>
                  </div>
                </dl>
                <div className="mt-4 space-y-2 border-t border-border pt-4 text-sm">
                  {analysis.summary ? (
                    <p>
                      <span className="font-semibold">Summary: </span>
                      {analysis.summary}
                    </p>
                  ) : null}
                  {analysis.reasoning ? (
                    <p className="text-muted-foreground">
                      <span className="font-semibold text-foreground">Reasoning: </span>
                      {analysis.reasoning}
                    </p>
                  ) : null}
                  {analysis.image_findings ? (
                    <p className="text-muted-foreground">
                      <span className="font-semibold text-foreground">Image findings: </span>
                      {analysis.image_findings}
                    </p>
                  ) : null}
                </div>
              </>
            ) : (
              <p className="mt-3 text-sm text-muted-foreground">
                No AI analysis stored for this complaint.
              </p>
            )}
          </section>

          {dupes.length ? (
            <section className="surface p-6">
              <div className="flex items-center gap-2">
                <Copy className="size-4 text-primary" />
                <h2 className="font-display text-lg font-semibold">Duplicate information</h2>
              </div>
              <ul className="mt-3 space-y-2 text-sm">
                {dupes.map((d) => (
                  <li
                    key={d.id}
                    className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border px-3 py-2"
                  >
                    <span>
                      {Math.round(Number(d.similarity) * 100)}% similar
                      {d.distance_m != null ? ` · ${d.distance_m} m away` : ""}
                      {d.linked ? " · linked by citizen" : ""}
                    </span>
                    <Link
                      to="/complaints/$id"
                      params={{ id: d.matched_complaint_id }}
                      className="font-semibold text-primary hover:underline"
                    >
                      View matched report
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}

          <section className="surface p-6">
            <h2 className="font-display text-lg font-semibold">Status timeline</h2>
            <ol className="mt-4 space-y-4">
              {history.map((h) => (
                <li key={h.id} className="flex gap-3">
                  <span className="mt-1 size-2.5 shrink-0 rounded-full bg-primary" />
                  <div>
                    <p className="text-sm font-semibold">
                      {STATUS_LABEL[h.to_status]}
                      {h.from_status ? (
                        <span className="font-normal text-muted-foreground">
                          {" "}
                          · from {STATUS_LABEL[h.from_status]}
                        </span>
                      ) : null}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatDateTime(h.created_at)} · {h.changed_by_name || "System"}
                    </p>
                    {h.note ? <p className="mt-1 text-sm">{h.note}</p> : null}
                  </div>
                </li>
              ))}
              {history.length === 0 ? (
                <li className="text-sm text-muted-foreground">No status changes recorded yet.</li>
              ) : null}
            </ol>
          </section>

          <section className="surface p-6">
            <h2 className="font-display text-lg font-semibold">Authority updates</h2>
            <ul className="mt-4 space-y-3">
              {updates.length === 0 ? (
                <li className="text-sm text-muted-foreground">No updates posted yet.</li>
              ) : (
                updates.map((u) => (
                  <li
                    key={u.id}
                    className="rounded-lg border border-border p-3 text-sm"
                  >
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      {u.is_internal ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-destructive">
                          <Lock className="size-3" /> Internal
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 font-semibold text-accent">
                          <Megaphone className="size-3" /> Public
                        </span>
                      )}
                      {u.author_name || "Authority"} · {formatDateTime(u.created_at)}
                    </div>
                    <p className="mt-1">{u.message}</p>
                  </li>
                ))
              )}
            </ul>
          </section>
        </div>

        {/* SIDEBAR */}
        <aside className="space-y-6">
          {isAuthority ? (
            <section className="surface p-5">
              <h2 className="font-display text-base font-semibold">Authority actions</h2>

              <div className="mt-4 space-y-1.5">
                <Label htmlFor="note">Note for the next status change (optional)</Label>
                <Textarea
                  id="note"
                  rows={2}
                  maxLength={400}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Verified on site with photo evidence."
                />
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                {ALL_STATUSES.filter((s) => s !== complaint.status).map((s) => (
                  <Button
                    key={s}
                    size="sm"
                    variant={s === "rejected" ? "destructive" : s === "resolved" ? "default" : "outline"}
                    disabled={statusMutation.isPending}
                    onClick={() => statusMutation.mutate(s)}
                  >
                    {STATUS_LABEL[s]}
                  </Button>
                ))}
              </div>

              <div className="mt-5 space-y-3 border-t border-border pt-4">
                <div className="space-y-1.5">
                  <Label>Assign department (override AI)</Label>
                  <Select
                    {...(complaint.department_id ? { value: complaint.department_id } : {})}
                    onValueChange={(value) => fieldMutation.mutate({ department_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      {departments.map((d) => (
                        <SelectItem key={d.id} value={d.id}>
                          {d.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1.5">
                  <Label>Priority</Label>
                  <Select
                    value={complaint.priority}
                    onValueChange={(value) => fieldMutation.mutate({ priority: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SEVERITIES.map((s) => (
                        <SelectItem key={s} value={s} className="capitalize">
                          {s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1.5">
                  <Label>Severity (override AI)</Label>
                  <Select
                    value={complaint.severity}
                    onValueChange={(value) => fieldMutation.mutate({ severity: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SEVERITIES.map((s) => (
                        <SelectItem key={s} value={s} className="capitalize">
                          {s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="mt-5 space-y-3 border-t border-border pt-4">
                <div className="space-y-1.5">
                  <Label htmlFor="publicMessage">Public update (visible to citizen)</Label>
                  <Textarea
                    id="publicMessage"
                    rows={2}
                    maxLength={500}
                    value={publicMessage}
                    onChange={(e) => setPublicMessage(e.target.value)}
                    placeholder="Repair crew scheduled for Thursday."
                  />
                  <Button
                    size="sm"
                    disabled={updateMutation.isPending || publicMessage.trim().length < 3}
                    onClick={() =>
                      updateMutation.mutate({ message: publicMessage, isInternal: false })
                    }
                  >
                    Post public update
                  </Button>
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="internalNote">Internal note (staff only)</Label>
                  <Textarea
                    id="internalNote"
                    rows={2}
                    maxLength={500}
                    value={internalNote}
                    onChange={(e) => setInternalNote(e.target.value)}
                    placeholder="Contractor quote pending."
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={updateMutation.isPending || internalNote.trim().length < 3}
                    onClick={() =>
                      updateMutation.mutate({ message: internalNote, isInternal: true })
                    }
                  >
                    Save internal note
                  </Button>
                </div>
              </div>
            </section>
          ) : (
            <section className="surface p-5">
              <h2 className="font-display text-base font-semibold">Progress</h2>
              <ol className="mt-4 space-y-3">
                {STATUS_FLOW.map((s) => {
                  const reached =
                    STATUS_FLOW.indexOf(complaint.status) >= STATUS_FLOW.indexOf(s) &&
                    complaint.status !== "rejected";
                  return (
                    <li key={s} className="flex items-center gap-3 text-sm">
                      <span
                        className={
                          reached
                            ? "size-2.5 rounded-full bg-success"
                            : "size-2.5 rounded-full bg-border"
                        }
                      />
                      <span className={reached ? "font-semibold" : "text-muted-foreground"}>
                        {STATUS_LABEL[s]}
                      </span>
                    </li>
                  );
                })}
              </ol>
              {complaint.status === "rejected" ? (
                <p className="mt-4 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                  This report was rejected by the authority.
                </p>
              ) : null}
            </section>
          )}
        </aside>
      </div>
    </div>
  );
}
