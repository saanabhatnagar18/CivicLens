import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { fetchMyComplaints } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import {
  ComplaintCard,
  EmptyState,
  ErrorBlock,
  LoadingBlock,
  StatCard,
} from "@/components/civic/complaint-ui";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Citizen Dashboard — CivicLens AI" },
      {
        name: "description",
        content: "Track every civic issue you have reported and its current resolution status.",
      },
      { property: "og:title", content: "Citizen Dashboard — CivicLens AI" },
      { property: "og:description", content: "Your reports, priorities and resolution progress." },
    ],
  }),
  component: CitizenDashboard,
});

function CitizenDashboard() {
  const { user, fullName } = useAuth();
  const { data, isLoading, error } = useQuery({
    queryKey: ["complaints", "mine", user?.id],
    queryFn: () => fetchMyComplaints(user!.id),
    enabled: Boolean(user?.id),
  });

  const complaints = data ?? [];
  const pending = complaints.filter((c) => ["submitted", "verified"].includes(c.status)).length;
  const inProgress = complaints.filter((c) => ["assigned", "in_progress"].includes(c.status)).length;
  const resolved = complaints.filter((c) => c.status === "resolved").length;

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow text-primary">Citizen dashboard</p>
          <h1 className="mt-2 text-2xl font-bold sm:text-3xl">
            {fullName ? `Hello, ${fullName.split(" ")[0]}` : "Your civic reports"}
          </h1>
        </div>
        <Button asChild>
          <Link to="/report">
            <Plus className="size-4" /> Report an Issue
          </Link>
        </Button>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total reports" value={complaints.length} />
        <StatCard label="Pending" value={pending} tone="primary" />
        <StatCard label="In progress" value={inProgress} tone="info" />
        <StatCard label="Resolved" value={resolved} tone="success" />
      </div>

      <h2 className="mt-10 font-display text-lg font-semibold">Recent reports</h2>
      <div className="mt-4">
        {isLoading ? (
          <LoadingBlock />
        ) : error ? (
          <ErrorBlock message={(error as Error).message} />
        ) : complaints.length === 0 ? (
          <EmptyState
            title="No reports yet"
            body="When you report a pothole, garbage pile or broken streetlight, it will appear here with its live status."
            action={
              <Button className="mt-3" asChild>
                <Link to="/report">Report your first issue</Link>
              </Button>
            }
          />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {complaints.slice(0, 6).map((c) => (
              <ComplaintCard key={c.id} complaint={c} />
            ))}
          </div>
        )}
      </div>

      {complaints.length > 6 ? (
        <div className="mt-6">
          <Button variant="outline" asChild>
            <Link to="/my-reports">View all reports</Link>
          </Button>
        </div>
      ) : null}
    </div>
  );
}
