import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Building2, ScanEye, User } from "lucide-react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/register")({
  head: () => ({
    meta: [
      { title: "Create an account — CivicLens AI" },
      {
        name: "description",
        content:
          "Register as a citizen to report civic issues, or as an authority to manage and resolve complaints.",
      },
      { property: "og:title", content: "Join CivicLens AI" },
      {
        property: "og:description",
        content: "Report civic issues or manage them as an authority.",
      },
    ],
  }),
  component: RegisterPage,
});

const schema = z.object({
  fullName: z.string().trim().min(2, "Enter your full name").max(80),
  email: z.string().trim().email("Enter a valid email").max(255),
  password: z.string().min(6, "Password must be at least 6 characters").max(72),
});

function RegisterPage() {
  const navigate = useNavigate();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"citizen" | "authority">("citizen");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const parsed = schema.safeParse({ fullName, email, password });
    if (!parsed.success) {
      const msg = parsed.error.issues[0]?.message ?? "Invalid details";
      setError(msg);
      return;
    }
    setLoading(true);
    const { data, error: signUpError } = await supabase.auth.signUp({
      email: parsed.data.email,
      password: parsed.data.password,
      options: {
        emailRedirectTo: window.location.origin,
        data: { full_name: parsed.data.fullName, role },
      },
    });
    setLoading(false);
    if (signUpError) {
      setError(signUpError.message);
      toast.error("Could not create account", { description: signUpError.message });
      return;
    }
    if (!data.session) {
      toast.success("Check your email to confirm your account");
      return;
    }
    toast.success("Account created");
    void navigate({ to: role === "authority" ? "/authority" : "/dashboard" });
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="hidden flex-col justify-between bg-ink p-10 text-ink-foreground lg:flex">
        <Link to="/" className="flex items-center gap-2.5">
          <span className="grid size-9 place-items-center rounded-xl bg-ink-foreground/10">
            <ScanEye className="size-5 text-primary" />
          </span>
          <span className="font-display text-lg font-bold">
            CivicLens<span className="text-primary"> AI</span>
          </span>
        </Link>
        <div>
          <h2 className="font-display text-3xl font-bold">
            Every complaint gets a name, a number and a deadline.
          </h2>
          <p className="mt-4 max-w-md opacity-70">
            Citizens report and track. Authorities verify, route and resolve. The whole timeline
            stays public to the reporter.
          </p>
        </div>
        <p className="text-xs opacity-50">Civic Technology · Public Impact</p>
      </div>

      <div className="flex items-center justify-center px-4 py-14">
        <div className="w-full max-w-sm">
          <h1 className="font-display text-2xl font-bold">Create your account</h1>
          <p className="mt-1 text-sm text-muted-foreground">Choose how you will use CivicLens AI.</p>

          <div className="mt-5 grid grid-cols-2 gap-3">
            {(
              [
                { key: "citizen", label: "Citizen", desc: "Report & track", icon: User },
                { key: "authority", label: "Authority", desc: "Manage & resolve", icon: Building2 },
              ] as const
            ).map((opt) => (
              <button
                key={opt.key}
                type="button"
                onClick={() => setRole(opt.key)}
                aria-pressed={role === opt.key}
                className={cn(
                  "rounded-xl border p-3 text-left transition-colors",
                  role === opt.key
                    ? "border-primary bg-primary/8 ring-2 ring-primary/25"
                    : "border-border hover:bg-muted",
                )}
              >
                <opt.icon className="size-4 text-primary" />
                <p className="mt-2 text-sm font-semibold">{opt.label}</p>
                <p className="text-xs text-muted-foreground">{opt.desc}</p>
              </button>
            ))}
          </div>

          <form onSubmit={onSubmit} className="mt-5 space-y-4" noValidate>
            <div className="space-y-1.5">
              <Label htmlFor="fullName">Full name</Label>
              <Input
                id="fullName"
                required
                maxLength={80}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Ananya Rao"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="new-password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 6 characters"
              />
            </div>

            {error ? (
              <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {error}
              </p>
            ) : null}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Creating account…" : "Create account"}
            </Button>
          </form>

          <p className="mt-6 text-sm text-muted-foreground">
            Already registered?{" "}
            <Link to="/login" className="font-semibold text-primary hover:underline">
              Log in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
