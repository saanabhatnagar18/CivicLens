export type Severity = "low" | "medium" | "high" | "critical";
export type ComplaintStatus =
  | "submitted"
  | "verified"
  | "assigned"
  | "in_progress"
  | "resolved"
  | "rejected";

export const STATUS_FLOW: ComplaintStatus[] = [
  "submitted",
  "verified",
  "assigned",
  "in_progress",
  "resolved",
];

export const STATUS_LABEL: Record<ComplaintStatus, string> = {
  submitted: "Submitted",
  verified: "Verified",
  assigned: "Assigned",
  in_progress: "In Progress",
  resolved: "Resolved",
  rejected: "Rejected",
};

export const SEVERITY_LABEL: Record<Severity, string> = {
  low: "Low",
  medium: "Medium",
  high: "High",
  critical: "Critical",
};

export const CATEGORIES = [
  "Roads & Potholes",
  "Garbage & Waste",
  "Water Leakage",
  "Broken Streetlight",
  "Drainage",
  "Traffic Issue",
  "Other Civic Issue",
] as const;

/** AI category -> responsible department slug (auto routing table). */
export const ROUTING: Record<string, string> = {
  "Roads & Potholes": "roads",
  "Garbage & Waste": "sanitation",
  "Water Leakage": "water",
  "Broken Streetlight": "electrical",
  Drainage: "drainage",
  "Traffic Issue": "traffic",
  "Other Civic Issue": "general",
};

export function departmentForCategory(category: string): string {
  return ROUTING[category] ?? "general";
}

const STOP_WORDS = new Set([
  "the","a","an","is","are","and","of","to","in","on","at","it","this","that","for","with","near","there","was","were","be","has","have","from","by","as","not","no","very","been","being","they","we","our","my",
]);

function tokenize(text: string): Set<string> {
  return new Set(
    text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .split(/\s+/)
      .filter((w) => w.length > 2 && !STOP_WORDS.has(w)),
  );
}

/** Jaccard text similarity between two complaint descriptions (0..1). */
export function textSimilarity(a: string, b: string): number {
  const ta = tokenize(a);
  const tb = tokenize(b);
  if (ta.size === 0 || tb.size === 0) return 0;
  let inter = 0;
  ta.forEach((t) => {
    if (tb.has(t)) inter += 1;
  });
  return inter / (ta.size + tb.size - inter);
}

/** Great-circle distance in metres. */
export function distanceMeters(
  lat1?: number | null,
  lon1?: number | null,
  lat2?: number | null,
  lon2?: number | null,
): number | null {
  if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) return null;
  const R = 6371000;
  const toRad = (v: number) => (v * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return Math.round(2 * R * Math.asin(Math.sqrt(s)));
}

export type DuplicateCandidate = {
  id: string;
  code: string;
  description: string;
  category: string;
  status: ComplaintStatus;
  latitude: number | null;
  longitude: number | null;
  created_at: string;
};

export type DuplicateResult = {
  candidate: DuplicateCandidate;
  similarity: number;
  distance: number | null;
  reason: string;
};

/**
 * Combined duplicate score: text similarity + same category + geo proximity.
 */
export function findDuplicates(
  description: string,
  category: string,
  lat: number | null,
  lng: number | null,
  candidates: DuplicateCandidate[],
): DuplicateResult[] {
  const results: DuplicateResult[] = [];
  for (const c of candidates) {
    const text = textSimilarity(description, c.description);
    const dist = distanceMeters(lat, lng, c.latitude, c.longitude);
    const sameCategory = c.category === category;
    const geoScore = dist == null ? 0 : dist <= 500 ? 1 - dist / 500 : 0;
    const score = text * 0.55 + (sameCategory ? 0.25 : 0) + geoScore * 0.2;
    if (score < 0.4) continue;
    const reasons: string[] = [`${Math.round(text * 100)}% text similarity`];
    if (sameCategory) reasons.push("same category");
    if (dist != null && dist <= 500) reasons.push(`${dist} m away`);
    results.push({
      candidate: c,
      similarity: Math.min(0.99, score),
      distance: dist,
      reason: reasons.join(", "),
    });
  }
  return results.sort((a, b) => b.similarity - a.similarity).slice(0, 3);
}

export function statusTone(status: ComplaintStatus) {
  switch (status) {
    case "resolved":
      return "success" as const;
    case "rejected":
      return "destructive" as const;
    case "in_progress":
      return "info" as const;
    case "assigned":
    case "verified":
      return "primary" as const;
    default:
      return "muted" as const;
  }
}

export function severityTone(level: Severity) {
  switch (level) {
    case "critical":
      return "destructive" as const;
    case "high":
      return "primary" as const;
    case "medium":
      return "warning" as const;
    default:
      return "muted" as const;
  }
}

export function formatDate(value: string | null | undefined) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString(undefined, {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function formatDateTime(value: string | null | undefined) {
  if (!value) return "—";
  return new Date(value).toLocaleString(undefined, {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
