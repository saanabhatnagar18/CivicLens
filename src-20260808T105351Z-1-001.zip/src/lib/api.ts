import { supabase } from "@/integrations/supabase/client";
import type { ComplaintStatus, Severity } from "@/lib/civic";

export type Department = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
};

export type Complaint = {
  id: string;
  code: string;
  citizen_id: string | null;
  reporter_name: string | null;
  title: string;
  description: string;
  category: string;
  subcategory: string | null;
  severity: Severity;
  priority: Severity;
  status: ComplaintStatus;
  department_id: string | null;
  location_text: string | null;
  latitude: number | null;
  longitude: number | null;
  image_url: string | null;
  ai_confidence: number | null;
  ai_summary: string | null;
  is_duplicate_of: string | null;
  resolved_at: string | null;
  created_at: string;
  updated_at: string;
};

export type AiAnalysisRow = {
  id: string;
  complaint_id: string;
  category: string | null;
  subcategory: string | null;
  severity: Severity | null;
  priority: Severity | null;
  department_slug: string | null;
  confidence: number | null;
  summary: string | null;
  reasoning: string | null;
  image_findings: string | null;
  model: string | null;
  demo_mode: boolean;
  created_at: string;
};

export type StatusHistoryRow = {
  id: string;
  complaint_id: string;
  from_status: ComplaintStatus | null;
  to_status: ComplaintStatus;
  changed_by_name: string | null;
  note: string | null;
  created_at: string;
};

export type UpdateRow = {
  id: string;
  complaint_id: string;
  author_name: string | null;
  message: string;
  is_internal: boolean;
  created_at: string;
};

export type DuplicateRow = {
  id: string;
  complaint_id: string;
  matched_complaint_id: string;
  similarity: number;
  distance_m: number | null;
  reason: string | null;
  linked: boolean;
  created_at: string;
};

const from = supabase.from.bind(supabase) as unknown as (
  table: string,
) => ReturnType<typeof supabase.from>;

async function unwrap<T>(promise: PromiseLike<{ data: unknown; error: { message: string } | null }>) {
  const { data, error } = await promise;
  if (error) throw new Error(error.message);
  return (data ?? []) as T;
}

export async function fetchDepartments() {
  return unwrap<Department[]>(from("departments").select("*").order("name"));
}

export async function fetchComplaints() {
  return unwrap<Complaint[]>(
    from("complaints").select("*").order("created_at", { ascending: false }),
  );
}

export async function fetchMyComplaints(userId: string) {
  return unwrap<Complaint[]>(
    from("complaints")
      .select("*")
      .eq("citizen_id", userId)
      .order("created_at", { ascending: false }),
  );
}

export async function fetchComplaint(id: string) {
  const { data, error } = await from("complaints").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  return (data as Complaint | null) ?? null;
}

export async function fetchAnalysis(complaintId: string) {
  const { data, error } = await from("ai_analysis")
    .select("*")
    .eq("complaint_id", complaintId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data as AiAnalysisRow | null) ?? null;
}

export async function fetchHistory(complaintId: string) {
  return unwrap<StatusHistoryRow[]>(
    from("complaint_status_history")
      .select("*")
      .eq("complaint_id", complaintId)
      .order("created_at", { ascending: true }),
  );
}

export async function fetchUpdates(complaintId: string) {
  return unwrap<UpdateRow[]>(
    from("complaint_updates")
      .select("*")
      .eq("complaint_id", complaintId)
      .order("created_at", { ascending: true }),
  );
}

export async function fetchDuplicates(complaintId: string) {
  return unwrap<DuplicateRow[]>(
    from("duplicate_matches").select("*").eq("complaint_id", complaintId),
  );
}

export async function fetchAllDuplicates() {
  return unwrap<DuplicateRow[]>(from("duplicate_matches").select("*"));
}

export async function changeStatus(params: {
  complaintId: string;
  from: ComplaintStatus;
  to: ComplaintStatus;
  note?: string;
  actorId: string;
  actorName: string;
}) {
  const patch: Record<string, unknown> = { status: params.to };
  if (params.to === "resolved") patch["resolved_at"] = new Date().toISOString();
  const { error } = await from("complaints").update(patch).eq("id", params.complaintId);
  if (error) throw new Error(error.message);
  const { error: histError } = await from("complaint_status_history").insert({
    complaint_id: params.complaintId,
    from_status: params.from,
    to_status: params.to,
    changed_by: params.actorId,
    changed_by_name: params.actorName,
    note: params.note ?? null,
  });
  if (histError) throw new Error(histError.message);
}

export async function updateComplaintFields(id: string, patch: Record<string, unknown>) {
  const { error } = await from("complaints").update(patch).eq("id", id);
  if (error) throw new Error(error.message);
}

export async function addUpdate(params: {
  complaintId: string;
  message: string;
  isInternal: boolean;
  authorId: string;
  authorName: string;
}) {
  const { error } = await from("complaint_updates").insert({
    complaint_id: params.complaintId,
    message: params.message,
    is_internal: params.isInternal,
    author_id: params.authorId,
    author_name: params.authorName,
  });
  if (error) throw new Error(error.message);
}
