import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { CATEGORIES, departmentForCategory, type Severity } from "@/lib/civic";

const InputSchema = z.object({
  description: z.string().trim().min(15).max(2000),
  locationText: z.string().trim().max(300).optional().nullable(),
  imageDataUrl: z
    .string()
    .max(8_000_000)
    .optional()
    .nullable()
    .refine((v) => !v || /^data:image\/(png|jpe?g|webp);base64,/.test(v), {
      message: "Unsupported image format",
    }),
});

export type AiAnalysis = {
  category: string;
  subcategory: string;
  severity: Severity;
  priority: Severity;
  departmentSlug: string;
  confidence: number;
  summary: string;
  reasoning: string;
  imageFindings: string | null;
  model: string;
  demoMode: boolean;
};

const SEVERITIES: Severity[] = ["low", "medium", "high", "critical"];
const coerceSeverity = (v: unknown): Severity =>
  SEVERITIES.includes(String(v).toLowerCase() as Severity)
    ? (String(v).toLowerCase() as Severity)
    : "medium";

/** Rule-based fallback so the full workflow still runs without an AI key. */
function demoAnalyse(description: string, hasImage: boolean): AiAnalysis {
  const t = description.toLowerCase();
  const rules: Array<{ cat: string; sub: string; words: string[] }> = [
    { cat: "Roads & Potholes", sub: "Pothole", words: ["pothole", "road", "tarmac", "gravel", "crater", "asphalt"] },
    { cat: "Garbage & Waste", sub: "Uncollected garbage", words: ["garbage", "trash", "waste", "dump", "litter", "bin"] },
    { cat: "Water Leakage", sub: "Pipeline leak", words: ["water", "leak", "pipeline", "pipe", "tap"] },
    { cat: "Broken Streetlight", sub: "Non-functional light", words: ["streetlight", "street light", "lamp", "bulb", "pole", "dark"] },
    { cat: "Drainage", sub: "Overflowing drain", words: ["drain", "sewage", "sewer", "waterlog", "flood"] },
    { cat: "Traffic Issue", sub: "Signal failure", words: ["traffic", "signal", "junction", "zebra", "sign"] },
  ];
  let best = { cat: "Other Civic Issue", sub: "General complaint", hits: 0 };
  for (const r of rules) {
    const hits = r.words.filter((w) => t.includes(w)).length;
    if (hits > best.hits) best = { cat: r.cat, sub: r.sub, hits };
  }
  const risky = ["accident", "danger", "unsafe", "spark", "child", "school", "hospital", "injur", "sewage", "electrocut"].some((w) => t.includes(w));
  const severity: Severity = risky ? "high" : best.hits >= 2 ? "medium" : "low";
  const priority: Severity = risky ? "high" : severity;
  return {
    category: best.cat,
    subcategory: best.sub,
    severity,
    priority,
    departmentSlug: departmentForCategory(best.cat),
    confidence: Math.min(0.82, 0.45 + best.hits * 0.1),
    summary: description.slice(0, 180),
    reasoning:
      "Demo AI mode: classified using keyword and safety-risk heuristics over the complaint text" +
      (hasImage ? " with an attached photo noted as supporting evidence." : "."),
    imageFindings: hasImage ? "Image attached (not analysed in demo mode)." : null,
    model: "demo-rules-v1",
    demoMode: true,
  };
}

export const analyseComplaint = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }): Promise<AiAnalysis> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    const hasImage = Boolean(data.imageDataUrl);
    if (!apiKey) return demoAnalyse(data.description, hasImage);

    const system = `You are CivicLens AI, a municipal complaint triage engine.
Analyse the citizen complaint (text, and the photo if provided) and classify it.
Allowed categories: ${CATEGORIES.join(", ")}.
Severity and priority must be one of: low, medium, high, critical.
Severity reflects physical/public-safety risk. Priority combines severity with how many people are affected and location sensitivity (schools, hospitals, junctions).
If a photo is given, describe what civic problem is visible (pothole, garbage, water leakage, broken streetlight, drainage, damaged road, infrastructure damage) in imageFindings; otherwise return null.
Respond with ONLY a JSON object using keys: category, subcategory, severity, priority, confidence (0-1 number), summary (max 2 sentences), reasoning (2-4 sentences explaining the classification), imageFindings.`;

    const userContent: Array<Record<string, unknown>> = [
      {
        type: "text",
        text: `Complaint description: ${data.description}\nReported location: ${data.locationText || "not provided"}`,
      },
    ];
    if (data.imageDataUrl) {
      userContent.push({ type: "image_url", image_url: { url: data.imageDataUrl } });
    }

    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3.6-flash",
          messages: [
            { role: "system", content: system },
            { role: "user", content: userContent },
          ],
          response_format: { type: "json_object" },
        }),
      });

      if (res.status === 429) throw new Error("RATE_LIMIT");
      if (res.status === 402) throw new Error("NO_CREDITS");
      if (!res.ok) throw new Error(`Gateway error ${res.status}`);

      const body = (await res.json()) as {
        choices?: Array<{ message?: { content?: string } }>;
      };
      const raw = body.choices?.[0]?.message?.content ?? "";
      const jsonText = raw.slice(raw.indexOf("{"), raw.lastIndexOf("}") + 1);
      const parsed = JSON.parse(jsonText) as Record<string, unknown>;

      const category = CATEGORIES.includes(String(parsed["category"]) as (typeof CATEGORIES)[number])
        ? String(parsed["category"])
        : "Other Civic Issue";
      const confidenceRaw = Number(parsed["confidence"]);
      const confidence = Number.isFinite(confidenceRaw)
        ? Math.max(0.3, Math.min(0.99, confidenceRaw > 1 ? confidenceRaw / 100 : confidenceRaw))
        : 0.75;

      return {
        category,
        subcategory: String(parsed["subcategory"] ?? "General"),
        severity: coerceSeverity(parsed["severity"]),
        priority: coerceSeverity(parsed["priority"]),
        departmentSlug: departmentForCategory(category),
        confidence,
        summary: String(parsed["summary"] ?? data.description.slice(0, 180)),
        reasoning: String(parsed["reasoning"] ?? ""),
        imageFindings: parsed["imageFindings"] ? String(parsed["imageFindings"]) : null,
        model: "google/gemini-3.6-flash",
        demoMode: false,
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : "unknown";
      if (message === "RATE_LIMIT" || message === "NO_CREDITS") throw error;
      console.error("AI analysis failed, using demo mode:", message);
      return demoAnalyse(data.description, hasImage);
    }
  });
