import { Link } from "@tanstack/react-router";
import { CalendarDays, MapPin } from "lucide-react";
import type { Complaint } from "@/lib/api";
import { formatDate } from "@/lib/civic";
import { PriorityBadge, StatusBadge } from "@/components/civic/badges";

export function StatCard({
  label,
  value,
  tone = "default",
}: {
  label: string;
  value: number | string;
  tone?: "default" | "primary" | "success" | "destructive" | "info";
}) {
  const toneClass = {
    default: "text-foreground",
    primary: "text-primary",
    success: "text-success",
    destructive: "text-destructive",
    info: "text-accent",
  }[tone];
  return (
    <div className="surface p-5">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className={`mt-1 font-display text-3xl font-bold ${toneClass}`}>{value}</p>
    </div>
  );
}

export function ComplaintCard({ complaint }: { complaint: Complaint }) {
  return (
    <Link
      to="/complaints/$id"
      params={{ id: complaint.id }}
      className="surface block p-5 transition-shadow hover:shadow-[var(--shadow-lift)]"
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="font-display text-sm font-bold text-primary">{complaint.code}</span>
        <StatusBadge status={complaint.status} />
      </div>
      <h3 className="mt-2 line-clamp-1 font-semibold">{complaint.title || complaint.category}</h3>
      <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{complaint.description}</p>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium">
          {complaint.category}
        </span>
        <PriorityBadge level={complaint.priority} label="Priority" />
      </div>
      <div className="mt-3 flex flex-wrap gap-4 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1">
          <MapPin className="size-3.5" />
          {complaint.location_text || "Location not provided"}
        </span>
        <span className="inline-flex items-center gap-1">
          <CalendarDays className="size-3.5" />
          {formatDate(complaint.created_at)}
        </span>
      </div>
    </Link>
  );
}

export function EmptyState({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="surface flex flex-col items-center gap-2 p-10 text-center">
      <h3 className="font-display text-lg font-semibold">{title}</h3>
      <p className="max-w-sm text-sm text-muted-foreground">{body}</p>
      {action}
    </div>
  );
}

export function LoadingBlock({ rows = 3 }: { rows?: number }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="surface h-40 animate-pulse bg-muted/50" />
      ))}
    </div>
  );
}

export function ErrorBlock({ message }: { message: string }) {
  return (
    <div className="rounded-xl border border-destructive/30 bg-destructive/10 p-6 text-sm text-destructive">
      Something went wrong: {message}
    </div>
  );
}
